function x = trirand(a, b, c)
% draw a sample from a triangular distribution with min=a, mode=b, max=c

x = ;

end